import streamlit as st
import numpy as np
import cv2
import tensorflow as tf
import pickle
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.preprocessing import image
from PIL import Image
from fpdf import FPDF
import os
import tempfile

# Load TFLite models
@st.cache_resource
def load_interpreters():
    classifier = tf.lite.Interpreter(model_path="diabetes_classifier.tflite")
    classifier.allocate_tensors()

    mobilenet = tf.lite.Interpreter(model_path="mobilenetv2_features.tflite")
    mobilenet.allocate_tensors()

    return classifier, mobilenet

classifier, mobilenet = load_interpreters()
classifier_input = classifier.get_input_details()
classifier_output = classifier.get_output_details()

mobilenet_input = mobilenet.get_input_details()
mobilenet_output = mobilenet.get_output_details()

# Load scaler
with open("scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

st.title("Non-Invasive Diabetes Detection")
st.markdown("Upload a tongue image and 30-sec PPG video for analysis.")

name = st.text_input("Name")
age = st.text_input("Age")

img_file = st.file_uploader("Upload Tongue Image", type=['jpg', 'jpeg', 'png'])
video_file = st.file_uploader("Upload PPG Video (30 seconds)", type=['mp4', 'avi'])
if video_file is not None:
    if video_file.size > 50 * 1024 * 1024:  # Limit: 10 MB
        st.error("File too large! Please upload a video less than 10 MB.")
    else:
        # Save the file or process as usual
        with open("uploaded_video.mp4", "wb") as f:
            f.write(video_file.getbuffer())
        st.success("Video uploaded successfully!")
        # Continue with your PPG processing...

if st.button("Predict"):
    if not img_file or not video_file:
        st.error("Please upload both tongue image and PPG video.")
    else:
        try:
            # Process image
            img = Image.open(img_file).convert('RGB')
            img = img.resize((224, 224))
            img_array = image.img_to_array(img)
            img_array = np.expand_dims(img_array, axis=0)
            img_array = preprocess_input(img_array)

            mobilenet.set_tensor(mobilenet_input[0]['index'], img_array.astype(np.float32))
            mobilenet.invoke()
            tongue_features = mobilenet.get_tensor(mobilenet_output[0]['index'])

            # Process video
            with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as tmp_video:
                tmp_video.write(video_file.read())
                tmp_path = tmp_video.name

            cap = cv2.VideoCapture(tmp_path)
            green_means = []
            while cap.isOpened():
                ret, frame = cap.read()
                if not ret:
                    break
                green_means.append(np.mean(frame[:, :, 1]))
            cap.release()

            green_means = np.array(green_means)
            stats = np.array([
                np.mean(green_means), np.std(green_means),
                np.max(green_means), np.min(green_means),
                np.median(green_means),
                np.max(green_means) - np.min(green_means),
                (3 * (np.mean(green_means) - np.median(green_means))) / (np.std(green_means) or 1)
            ]).reshape(1, -1)

            # Combine features
            combined = np.concatenate([tongue_features, stats], axis=1)
            scaled = scaler.transform(combined.astype(np.float32))

            # Predict
            classifier.set_tensor(classifier_input[0]['index'], scaled.astype(np.float32))
            classifier.invoke()
            pred = classifier.get_tensor(classifier_output[0]['index'])[0][0]

            result = "Diabetic" if pred >= 0.5 else "Non-Diabetic"
            st.success(f"Prediction Result: {result}")

            # Generate report
            advice = "Consult a doctor." if result == "Diabetic" else "Maintain a healthy lifestyle."
            report = f"Name: {name}\nAge: {age}\nResult: {result}\nAdvice: {advice}"
            st.text_area("Report", report, height=150)

            # Create PDF
            pdf = FPDF()
            pdf.add_page()
            pdf.set_font("Arial", size=12)
            pdf.cell(200, 10, txt="Diabetes Detection Report", ln=True, align='C')
            pdf.ln(10)
            pdf.cell(200, 10, txt=f"Name: {name}", ln=True)
            pdf.cell(200, 10, txt=f"Age: {age}", ln=True)
            pdf.cell(200, 10, txt=f"Result: {result}", ln=True)
            pdf.multi_cell(0, 10, txt=f"Advice: {advice}")

            pdf_path = os.path.join(tempfile.gettempdir(), f"{name}_report.pdf")
            pdf.output(pdf_path)
            with open(pdf_path, "rb") as f:
                st.download_button(label="Download PDF Report", data=f, file_name=f"{name}_report.pdf")
        except Exception as e:
            st.error(f"Prediction failed: {str(e)}")
